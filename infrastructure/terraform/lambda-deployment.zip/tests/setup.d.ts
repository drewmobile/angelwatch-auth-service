import 'jest';
//# sourceMappingURL=setup.d.ts.map